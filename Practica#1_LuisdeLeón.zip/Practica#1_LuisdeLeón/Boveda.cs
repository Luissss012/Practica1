﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_1_LuisdeLeón
{
    internal class Boveda
    {
        public string Moneda;
        public int Billete50;
        public int Billete10;
        public int Billete1;

        public string getMoneda() { return Moneda; }
        public int getBillete50() { return Billete50; }
        public int getBillete10() { return Billete10; }
        public int getBillete1() { return Billete1; }
        public void setMoneda(string moneda) { this.Moneda = moneda; }
        public void setBillete50(int billete50) { this.Billete50 = billete50; }
        public void setBillete10(int billete10) { this.Billete10 = billete10;}
        public void setBillete1(int billete1) { this.Billete1 = billete1;}

        public Boveda(string moneda, int billetes50,int billetes10,int billete1)
        {
            Moneda = moneda;
            Billete50 = billetes50;
            Billete10 = billetes10;
            Billete1 = billete1;
        }
        public int ObtenerSaldo()
        {
            return (Billete50 * 50) + (Billete10 * 10) + (Billete1);
        }
        public bool Retirar(int monto)
        {
            if (monto > ObtenerSaldo()) return false;

            int retirar50 = (int)(monto / 50);
            if(retirar50 > Billete50) retirar50 = Billete50;
            monto -= retirar50 * 50;

            int retirar10 = (int)(monto / 10);
            if(retirar10 > Billete10) retirar10 = Billete10;
            monto -= retirar10 * 10;

            int retirar1 = (int)(monto / 1);
            if(retirar1 > Billete1) retirar1 = Billete1;
            monto -= retirar10 * 11;

            if (monto == 0)
            {
                Billete50 -= retirar50;
                Billete10 -= retirar10;
                Billete1 -= retirar1;
                return true;
            }
            return false;
        }
        public void Depositar(int billete50, int billete10, int billete1)
        {
            Billete50 = billete50;
            Billete10 = billete10;
            Billete1 = billete1;
        }

    }
}
