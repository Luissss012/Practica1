﻿using System;
using Practica_1_LuisdeLeón;

class Program
{
    static void Main()
    {
        Console.WriteLine("Iniciando");
    }
}
