﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_1_LuisdeLeón
{
    internal class Autobanco
    {
        private List<Cuenta> cuentas = new List<Cuenta> { };
        private Boveda bovedaQ = new Boveda("Quetzales", 10, 20, 50);

        public void Iniciar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("+++AUTOBANCO+++");
                Console.WriteLine("1. Configuración de Cuentas");
                Console.WriteLine("2. Realizar Retiro");
                Console.WriteLine("3. Realizar Deposito");
                Console.WriteLine("4. Salir");
                Console.Write("Seleccione una opción: ");
                string opción = Console.ReadLine();

                switch (opción)
                {
                    case "1":
                        ConfigurarCuenta();
                        break;
                    case "2":
                        RealizarRetiro();
                        break;
                    case "3":
                        RealizarDeposito();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Opción Invalida. Presione ENTER para continuar");
                        Console.ReadLine();
                        break;

                }
            }
        }
        private void ConfigurarCuenta()
        {
            if (cuentas.Count >= 3)
            {
                Console.WriteLine("Ya hay tres cuentas registradas.");
                Console.ReadLine ();
                return;
            }
            Console.Write("Ingrese número de cuenta: ");
            string numeroCuenta = Console.ReadLine();

            Console.Write("Ingrese PIN: ");
            string pin = Console.ReadLine();

            Console.Write("Ingrese saldo Incial: ");
            int saldo = int.Parse(Console.ReadLine());

            cuentas.Add(new Cuenta(numeroCuenta, pin, saldo));
            Console.WriteLine("Cuenta registrada existósamente.");
            Console.ReadLine();
        }
        private void RealizarRetiro()
        {
            Console.Write("Ingrese número de cuenta: ");
            string numeroCuenta = Console.ReadLine();

            Cuenta cuenta = cuentas.Find(c => c.NumeroCuenta == numeroCuenta);
            if (cuenta == null)
            {
                Console.WriteLine("Cuenta no encontrada.");
                Console.ReadLine();
                return;
            }
            Console.Write("Ingrese PIN: ");
            string pin = Console.ReadLine();
            Console.ReadLine();
            if (!cuenta.ValidarPin(pin)) 
            {
                Console.WriteLine("PIN Incorrecto.");
                Console.ReadLine();
                return;
            }
            Console.Write("Ingrese monto a retirar: ");
            int monto = int.Parse(Console.ReadLine());
            if (cuenta.Retirar(monto)&& bovedaQ.Retirar(monto))
            {
                Console.WriteLine($"Retiro exitoso. Nuevo salod:{cuenta.Saldo}");
            }
            else
            {
                Console.WriteLine("Fondos insuficientes.");
            }
            Console.ReadLine();
        }
        private void RealizarDeposito()
        {
            Console.WriteLine("Ingrese número de cuenta: ");
            string numeroCuenta = Console.ReadLine();

            Cuenta cuenta = cuentas.Find(c => c.NumeroCuenta==numeroCuenta);
            if (cuenta == null)
            {
                Console.WriteLine("Cuenta no encontrada.");
                Console.ReadLine();
                return;
            }
            Console.Write("Ingrese monto a despositar: ");
            int monto = int.Parse(Console.ReadLine());

            cuenta.Depositar(monto);
            Console.WriteLine($"Deposito exitoso. Nuevo saldo: {cuenta.Saldo}");
            Console.ReadLine();
        }
    }
}
