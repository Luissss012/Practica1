﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_1_LuisdeLeón
{
    internal class Cuenta
    {
        public string NumeroCuenta;
        public string Pin;
        public int Saldo;

        public string getNumeroCuenta() {  return NumeroCuenta; }
        public string getPin() { return Pin; }
        public int getSaldo() { return Saldo; }
        public void setNumeroCuenta(string numeroCuenta) {this.NumeroCuenta = numeroCuenta;}
        public void setPin(string pin) {this.Pin = pin;}
        public void setSaldo(int saldo) {this.Saldo = saldo;}

        public Cuenta(string numeroCuenta,string Pin, int SaldoInicial)
        {
            numeroCuenta = NumeroCuenta;
            this.Pin = Pin;
            Saldo = SaldoInicial;
        }
        public bool ValidarPin(string pinIngresado)
        {
            return Pin == pinIngresado;
        }
        public bool Retirar(int monto)
        {
            if(Saldo >= monto)
            {
                Saldo -= monto;
                return true;
            }
            return false;
        }
        public void Depositar(int monto)
        {
            Saldo+= monto;
        }
    }
}
